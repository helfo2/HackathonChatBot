﻿namespace FleetChatBotServer.UGProMiddleware.Dtos
{
    public class OperatorDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Registration { get; set; }
    }
}
