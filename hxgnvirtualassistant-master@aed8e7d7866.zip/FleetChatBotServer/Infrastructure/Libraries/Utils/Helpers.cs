﻿using FleetChatBotServer.Infraestructure.Libraries.Utils.Serialization;

namespace FleetChatBotServer.Infraestructure.Libraries.Utils
{
    public class Helpers
    {
        /// <summary>
        /// Functions to help with serialization
        /// </summary>
        public static readonly JsonSerializerHelper JsonSerializer = new JsonSerializerHelper();

    }
}