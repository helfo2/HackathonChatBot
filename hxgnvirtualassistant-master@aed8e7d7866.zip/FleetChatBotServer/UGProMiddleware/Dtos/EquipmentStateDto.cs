﻿namespace FleetChatBotServer.UGProMiddleware.Dtos
{
    public class EquipmentStateDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
