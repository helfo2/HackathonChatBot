﻿namespace FleetChatBotServer.Infrastructure.Commons.HttpConnection
{
    public sealed class HttpPostBody: HttpBaseBody
    {
        public object Content { get; set; }
    }
}
