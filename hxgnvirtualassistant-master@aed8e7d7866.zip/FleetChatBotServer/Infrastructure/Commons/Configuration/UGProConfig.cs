﻿using FleetChatBotServer.Infrastructure.Commons.Configuration;
using FleetChatBotServer.Infrastructure.Commons.HttpConnection;

namespace Hxgn.Mop.UG.Simulator.Infrastructure.Commons.Configuration
{
    public class UGProConfig
    {
        public HttpConnectionConfig WebApi { get; set; }
    }
}