﻿namespace FleetChatBotServer.Infrastructure.Commons.HttpConnection
{
    public sealed class HttpResquestBody : HttpBaseBody { }
}
