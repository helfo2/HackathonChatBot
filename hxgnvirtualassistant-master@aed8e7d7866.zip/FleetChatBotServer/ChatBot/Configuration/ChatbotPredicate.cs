﻿namespace FleetChatBotServer.ChatBot.Configuration
{
    public class ChatbotPredicate
    {
        public int Key { get; set; }
        public string Name { get; set; }
    }
}
