![Alt Text](FleetChatBotUI/assets/hexagon-bot.png "Hexagon Virtual Assistant")
# Hexagon virtual assistant
Useful ChatBot (Virtual assistant) to allow mine dispatchers to use voice to make queries through the application of AI for voice recognition and chat

# Learn More
[Hexagon virtual assistant project](https://confluence.hexagonmining.com/display/MIN/Hexagon+virtual+assistant)

# Contributors
@dosa
@fehe
@sanr
